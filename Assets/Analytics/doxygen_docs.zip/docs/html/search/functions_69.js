var searchData=
[
  ['initialize',['initialize',['../class_strobotnik_1_1_g_u_a_1_1_google_universal_analytics.html#ac5c8265857242cdbc9cc5b200082714c',1,'Strobotnik::GUA::GoogleUniversalAnalytics']]]
];
