var searchData=
[
  ['anonymizeip',['anonymizeIP',['../class_strobotnik_1_1_g_u_a_1_1_google_universal_analytics.html#a89e780a3bdacf742a9e8325515f78879',1,'Strobotnik::GUA::GoogleUniversalAnalytics']]],
  ['appid',['appID',['../class_strobotnik_1_1_g_u_a_1_1_google_universal_analytics.html#a04b70665290f5e0ad551850039dac834',1,'Strobotnik::GUA::GoogleUniversalAnalytics']]],
  ['appname',['appName',['../class_strobotnik_1_1_g_u_a_1_1_google_universal_analytics.html#a6db5f66616c76c202d61b498aaee0faa',1,'Strobotnik::GUA::GoogleUniversalAnalytics']]],
  ['appversion',['appVersion',['../class_strobotnik_1_1_g_u_a_1_1_google_universal_analytics.html#a0311862ae6cca4a24fb8aed842eb5b37',1,'Strobotnik::GUA::GoogleUniversalAnalytics']]]
];
